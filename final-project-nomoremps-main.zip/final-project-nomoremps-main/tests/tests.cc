#include "catch.hpp"
#include "game.hpp"

TEST_CASE("Testing starting room, [StartingRoom]"){
    SECTION("Room structures"){
        Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
        Trap* trap_room_1 = new Trap("What is 9 + 10", "19");
        Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
        starting_point->right = trap_room_1;
        starting_point->down = normal_room_1;
        REQUIRE(starting_point->is_key_room_);
        REQUIRE(starting_point->right == trap_room_1);
        REQUIRE(starting_point->down == normal_room_1);
    }
}

TEST_CASE("Testing trap room 1, [TrapRoom1]"){
    SECTION("Room structures"){
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Trap* trap_room_1 = new Trap("What is 9 + 10", "19");
    Trap* trap_room_3 = new Trap("Where is cs128 class held", "siebel");
    Room* normal_room_3 = new Room("Normal Room 3", "This room is nothing special", {}, false,false);
    trap_room_1->left = starting_point;
    trap_room_1->down = trap_room_3;
    trap_room_1->right = normal_room_3;
    REQUIRE(trap_room_1->is_trap_room_);
    REQUIRE(trap_room_1->left == starting_point);
    REQUIRE(trap_room_1->down == trap_room_3);
    REQUIRE(trap_room_1->right == normal_room_3);
    REQUIRE(trap_room_1->IsCorrectAnswer("19"));

    }
}

TEST_CASE("Testing trap room 2, [TrapRoom2]"){
    SECTION("Room structures"){
    Trap* trap_room_2 = new Trap("What is our TA's First Name", "greg");
    Trap* trap_room_3 = new Trap("Where is cs128 class held", "siebel");
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
    Room* key_room = new Room("Key Room", "This is the key room and has a key", {new Item("key", "It's a key.")}, false,false);
    trap_room_2->up = trap_room_3;
    trap_room_2->right = key_room;
    trap_room_2->left = normal_room_1;
    REQUIRE(trap_room_2->is_trap_room_);
    REQUIRE(trap_room_2->up == trap_room_3);
    REQUIRE(trap_room_2->right == key_room);
    REQUIRE(trap_room_2->left == normal_room_1);
    REQUIRE(trap_room_2->IsCorrectAnswer("greg"));
    }
}

TEST_CASE("Testing trap room 3, [TrapRoom3]"){
    SECTION("Room structures"){
    Trap* trap_room_3 = new Trap("Where is cs128 class held", "siebel");
    Trap* trap_room_1 = new Trap("What is 9 + 10", "19");
    Trap* trap_room_2 = new Trap("What is our TA's First Name", "greg");
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
    Room* key_room = new Room("Key Room", "This is the key room and has a key", {new Item("key", "It's a key.")}, false,false);
    trap_room_3->up = trap_room_1;
    trap_room_3->left = normal_room_1;
    trap_room_3->right = key_room;
    trap_room_3->down = trap_room_2;
    REQUIRE(trap_room_3->is_trap_room_);
    REQUIRE(trap_room_3->up == trap_room_1);
    REQUIRE(trap_room_3->left == normal_room_1);
    REQUIRE(trap_room_3->right == key_room);
    REQUIRE(trap_room_3->down == trap_room_2);
    REQUIRE(trap_room_3->IsCorrectAnswer("siebel"));
    }
}

TEST_CASE("Testing normal room 1, [NormalRoom1]"){
    SECTION("Room structures"){
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
    Trap* trap_room_2 = new Trap("What is our TA's First Name", "greg");
    Trap* trap_room_3 = new Trap("Where is cs128 class held", "siebel");
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Room* normal_room_2 = new Room("Normal Room 2", "This room is nothing special", {}, false,false);
    normal_room_1->up = starting_point;
    normal_room_1->down = normal_room_2;
    normal_room_1->right = trap_room_3;
    normal_room_1->left = trap_room_2;
    REQUIRE_FALSE(normal_room_1->is_key_room_);
    REQUIRE_FALSE(normal_room_1->is_trap_room_);
    REQUIRE(normal_room_1->up == starting_point);
    REQUIRE(normal_room_1->down == normal_room_2);
    REQUIRE(normal_room_1->right == trap_room_3);
    REQUIRE(normal_room_1->left == trap_room_2);
    }

}
TEST_CASE("Testing normal room 2, [NormalRoom2]"){
    SECTION("Room structures"){
        Room* normal_room_2 = new Room("Normal Room 2", "This room is nothing special", {}, false,false);
        Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
        normal_room_2->up = normal_room_1;
        REQUIRE_FALSE(normal_room_2->is_key_room_);
        REQUIRE_FALSE(normal_room_2->is_trap_room_);
        REQUIRE(normal_room_2->up == normal_room_1);
    }

}
TEST_CASE("Testing normal room 3, [NormalRoom3]"){
    SECTION("Room structures"){
        Room* normal_room_3 = new Room("Normal Room 3", "This room is nothing special", {}, false,false);
        Trap* trap_room_1 = new Trap("What is 9 + 10", "19");
        normal_room_3->left = trap_room_1;
        REQUIRE_FALSE(normal_room_3->is_key_room_);
        REQUIRE_FALSE(normal_room_3->is_trap_room_);
        REQUIRE(normal_room_3->left == trap_room_1);
    }

}
TEST_CASE("Testing room with key, [KeyRoom]"){
    SECTION("Room structures"){
        Room* key_room = new Room("Key Room", "This is the key room and has a key", {new Item("key", "It's a key.")}, false,false);
        Trap* trap_room_2 = new Trap("What is our TA's First Name", "greg");
        Trap* trap_room_3 = new Trap("Where is cs128 class held", "siebel");
        key_room->up = trap_room_3;
        key_room->left = trap_room_2;
        REQUIRE_FALSE(key_room->is_key_room_);
        REQUIRE_FALSE(key_room->is_trap_room_);
        REQUIRE(key_room->up == trap_room_3);
        REQUIRE(key_room->left == trap_room_2);
    }

}

TEST_CASE("Player Change Position 1: Starting Room -> Normal Room") {
    Character player = Character();
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Room* normal_room_1 = new Room("Normal Room 3", "This room is nothing special", {new Potion(30)}, false,false);
    starting_point->right = normal_room_1;
    player.ChangePosition(normal_room_1);
    REQUIRE(player.GetPosition() == normal_room_1);
}

TEST_CASE("Player Change Position 2: Multiple Movement Commands") {
    Character player = Character();
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {new Potion(30)}, false,false);
    Room* normal_room_2 = new Room("Normal Room 2", "This room is nothing special", {new Potion(30)}, false,false);

    starting_point->right = normal_room_1;
    normal_room_1->down = normal_room_2;

    player.ChangePosition(normal_room_1);
    player.ChangePosition(normal_room_2);

    REQUIRE(player.GetPosition() == normal_room_2);
}

TEST_CASE("Adding item to inventory, [AddingItem]") {
    Character player = Character();
    player.SetItems({new Item("Key", "It is a key")});
    player.AddItem(new Item("Sword", "A weapon"));
    REQUIRE(player.GetBackpack()[0]->getName() == "Key");
    REQUIRE(player.GetBackpack()[1]->getName() == "Sword");
}

TEST_CASE("Player using Potion to increase health, [UsePotion]") {
    Character player = Character();
    player.AddItem(new Potion(30));

    REQUIRE(player.GetBackpack()[0]->getName() == "Potion");
    REQUIRE(player.GetBackpack()[0]->Use() == std::pair<int,int>(1,30));
}

TEST_CASE("Player Movement 1 - Basic, [PlayerMovementBasic1]") {
    Character player = Character();
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
    Room* normal_room_2 = new Room("Normal Room 2", "This room is nothing special", {new Potion(30)}, false,false);

    starting_point->right = normal_room_1;
    normal_room_1->down = normal_room_2;

    player.Move("right");
    player.ChangePosition(normal_room_1);
    REQUIRE(player.GetPosition() == normal_room_1);
}

TEST_CASE("Wrong Answer in Trap Room, [TrapRoom]") {
    Character player = Character();
    Room* starting_point = new Room("Starting", "This is the starting room and have a locked door", {new Potion(30)}, true,false);
    Trap* trap_room_1 = new Trap("What is 9 + 10", "19");
    Room* normal_room_1 = new Room("Normal Room 1", "This room is nothing special", {}, false,false);
    starting_point->right = trap_room_1;
    starting_point->down = normal_room_1;

    player.SetHealth(100);
    player.ChangePosition(trap_room_1);

    //REQUIRE(trap_room_1->IsCorrectAnswer("19"));
    //IsCorrectAnswer("17") // Real answer is 19, wrong answer inputted here
    REQUIRE_FALSE(trap_room_1->IsCorrectAnswer("17"));

    player.ChangeHealth(-50);
    REQUIRE(player.GetHealth() == 50);
}